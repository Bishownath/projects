<?php  
require '../db/db.php'; //requiring the database

?>
<main>

<form action="method"><!-- form is created-->
<?php
$furniture = $pdo->prepare('SELECT * FROM furniture '); //selectiing from furniture
$furniture->execute(); //executing the furniture
$furniT = $furniture->fetchAll(); //fetching the furniture

?>

<label >Furniture: </label> <!--Label  -->
<select name="furniture_id" > <!-- selecting from the name-->
<?php   
foreach($furniT as $furniture){?> <!-- using for each -->
<option value="<?php echo $furniture['id']?>"><?php echo $furniture['name']?></option> <!-- option value for the furniture-->

<?php }?>
</select>

<label >Image:</label> <!-- label as image-->
<input type="file" name="files[]" required> <!-- inputting the image as a file-->


<input type="submit" name="submit" value="Upload"> <!--submitting -->

</form><!-- form end-->
</main>
