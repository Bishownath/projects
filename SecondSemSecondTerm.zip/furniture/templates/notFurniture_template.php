
<?php
require  '../classes/databaseTable.php';
require '../db/db.php';


//important 
function getOneImage($furnitureId){
	$pdo = new PDO('mysql:dbname=furniture;host=localhost', 'root', '', [PDO::ATTR_ERRMODE =>  PDO::ERRMODE_EXCEPTION ]);
	$imageDb  =  $pdo->prepare("SELECT image FROM image   WHERE furniture_id=:fid ");
	$imageDb->execute(['fid'=>$furnitureId ]);

	$oneImg = $imageDb->fetchColumn();

	return $oneImg;

} 

function  getAllImages($furnitureId){
	$pdo = new PDO('mysql:dbname=furniture;host=localhost', 'root', '', [PDO::ATTR_ERRMODE =>  PDO::ERRMODE_EXCEPTION ]);
	$imageDb  =  $pdo->prepare("SELECT * FROM image   WHERE furniture_id=:fid ");
	$imageDb->execute(['fid'=>$furnitureId ]);

	$allImg = $imageDb->fetchAll();

	return $allImg;
}





 function loadAllFurnitures(){
 	$pdo = new PDO('mysql:dbname=furniture;host=localhost', 'root', '', [PDO::ATTR_ERRMODE =>  PDO::ERRMODE_EXCEPTION ]);
 	$furnituresOnDBiswo = $pdo->prepare("SELECT * FROM furniture  WHERE display=:display ");
 	$furnituresOnDBiswo->execute(['display'=>'Shown']);
 	foreach($furnituresOnDBiswo as $bish  ){
		 echo '<li>';
		
		echo '<a href="images/furniture/' . getOneImage($bish['id'])  . '"><img src="images/furniture/' . getOneImage($bish['id']) . '" /></a>';
		echo '<div class="details">';
		echo '<h2>' . $bish['name'] . '</h2>';
		echo '<h3>' . $bish['name'] . '</h3>';
		echo '<h4>£' . $bish['price'] . '</h4>';
		echo '<p>' . $bish['description'] . '</p>';
		echo '</div>';	
		echo '<div>';
		echo "<hr>";
		echo "<u>Images</u>";
		echo "<br><br>";
		$images=getAllImages($bish['id']);
		foreach($images as $i){
			echo '<a href="images/furniture/' . $i['image']  . '">
			<img src="images/furniture/' . $i['image'] . '" /></a>';
		
		}
		echo '</div>';	
		echo '</li>';
 	}
 
 }



 function loadOfCategory($categoryId,$name){
	 echo '<br>';
	 echo '<hr>';
			echo '<h2>'.$name.'</h2>';
			
 		$pdo = new PDO('mysql:dbname=furniture;host=localhost', 'root', '', [PDO::ATTR_ERRMODE =>  PDO::ERRMODE_EXCEPTION ]);
 	$furnituresOnDBiswo = $pdo->prepare("SELECT * FROM furniture  WHERE display=:display  AND  categoryId=:categoryid   ");
 	$furnituresOnDBiswo->execute(['display'=>'Shown'   , 'categoryid' => $categoryId   ]);
 	foreach($furnituresOnDBiswo as $bish  ){
		 echo '<li>';
		 getAllImages($bish['id']);
		echo '<a href="images/furniture/' . getOneImage($bish['id'])  . '.jpg"><img src="images/furniture/' .getOneImage($bish['id']) . '" /></a>';
		echo '<div class="details">';
		echo '<h2>' . $bish['name'] . '</h2>';
		echo '<h3>' . $bish['name'] . '</h3>';
		echo '<h4>£' . $bish['price'] . '</h4>';
		echo '<p>' . $bish['description'] . '</p>';
		echo '</div>';
		echo '</li>';
 	}

 }



   ?>

<main class="admin">
	<section class="left">
		<ul>
			<?php 
				$dbCategory = $pdo->prepare("SELECT * FROM category");
	    		$dbCategory->execute();
				
				foreach($dbCategory as  $categoryPres){?>
					<li><a href="<?php echo "furniture?categoryId=".$categoryPres['id'] ?>">
					<form method="POST" >
						<input type="hidden" name="hiddenSpecific"   value="<?php echo $categoryPres['id']; ?>"  >
						<input type="submit" style="margin-left: 0px;background: inherit;border: none;color: white;font-size: 20px;"  
						  name="showSpecific" value="<?php echo $categoryPres['name']; ?>"  >
					</form>
			<?php	}
			
				

			?>  

		</ul>
	</section>

	<section class="right">

		<h1>Furniture</h1>

	<ul class="furniture">

			<?php

		if(empty($_POST)){
			loadAllFurnitures();
		}	
		else{
			loadOfCategory($_POST['hiddenSpecific'],$_POST['showSpecific']);
		}
			  ?>

	</ul>

</main>	