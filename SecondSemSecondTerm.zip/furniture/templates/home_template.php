
<main class="home">
	<h1>Fran's Furniture</h1><br><br>
	<h2 style="text-align: center; ">Home Page</h2><br><br>

<p>Welcome to Fran's Furniture. <br><br><br><br>We're a family run furniture shop based in Northampton. <br><br><br><br><br><br><br> We stock a wide variety of modern and antique furniture including laps, bookcases, beds and sofas.</p>

</main>