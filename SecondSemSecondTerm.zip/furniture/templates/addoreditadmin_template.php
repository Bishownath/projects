<?php

require '../db/db.php'; //requiring the database


if( isset($_POST['name'])  &&  isset($_POST['email']) && isset($_POST['username'])  && isset($_POST['toeditof']) ){ //if isset if used for name email and username and to edit the info 

	if($_POST['toeditof'] == ''){
	$insertAd= $pdo->prepare("INSERT INTO tbl_admin (name,email,username,password) VALUES (:name,:email,:username,:password)"); //inserting from the table admin from database 
		if(  $insertAd->execute(['name'=>$_POST['name'],'email'=>$_POST['email'],'username'=>$_POST['username'],
									'password'=>$_POST['password']    ])    ){
			header('location:adminuser'); //location to admin user
		}	
	}

	else{

$updateAd = $pdo->prepare('UPDATE tbl_admin SET name=:name, email=:email, username=:username ,password=:password  
							 WHERE id=:id'); //updating the table admin in the database table 

	if(  $updateAd->execute([ 'id'=>$_POST['toeditof'] ,'name'=>$_POST['name'],'email'=>$_POST['email'],
								'username'=>$_POST['username'],'password'=>$_POST['password']
		                              ])   ){
		header('location:adminuser'); //if the update is execute then the location goes to admin user
	}


	}


}
 ?>

<main>

<div class="addEditForm">	 <!--creating the div class for add edit form  -->
	<br>
	<h3><u>Add/Edit Administrator</u></h3> <!-- heading for the add and edit admin-->

<br><br><br>

 
<form method="POST"><!-- method is post-->
	
<label>Name: </label> <!-- label as name-->
<input type="text" name="name"  value="<?php  if(isset( $_POST["hiddenName"])){  echo $_POST["hiddenName"]; }?>"   required >
<label>Email: </label> <!-- label as email-->
<input type="text" name="email"  value="<?php  if(isset( $_POST["hiddenEmail"])){  echo $_POST["hiddenEmail"]; }?>"   required >
<label>Username  : </label><!--label as username -->
<input type="text" name="username"  value="<?php  if(isset( $_POST["hiddenUsername"])){  echo $_POST["hiddenUsername"]; }?>"  required >
<label>Password: </label><!-- label as password-->
<input type="password" name="password"  value=""   required ><!-- input as password -->
<input type="hidden" name="toeditof"  value="<?php  if(isset( $_POST["editValue"])){  echo $_POST["editValue"]; }?>"> <!--input for the  -->

<input type="submit" name="" value="Save"> <!-- submitting the form-->

</form>

</div>

</main>

 
<style> /* using the css */
	

.addEditForm{
	text-align: center; /* text aligned to center*/ 
	padding:20px; /*padding is 20 pixel*/
}


</style>