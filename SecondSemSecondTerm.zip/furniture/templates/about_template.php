
<main class="home">  
	<!-- class name to home -->

	<p>Welcome to Fran's Furniture where we sell different kind of furnitures including the cupboard, table, and many more. <br><br> We're a family run furniture shop based in Northampton and on being the member to our site clients get the special discount . <br><br> We stock a wide variety of modern and antique furniture including laps, bookcases, beds and sofas and the client get the special discount.</p>
	<!-- adding paragraph -->


	<br><br><b><br><br>
		<h2>Furniture Design Ideas</h2>
		<p>The vintage looking furnishings, and the design of the furnitures in the house reflects the taste of the rich people.</p>
		<br><br><br><br>
		<h2>Hire a Pro</h2>
</main>