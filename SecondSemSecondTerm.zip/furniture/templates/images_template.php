<?php 
require '../db/db.php'; //connection

if(  isset($_POST['delImage'])  ){ //if condition 
	$dAdminImage = $_POST['delImage']; //
	unset($_POST['delImage']);//unsetting the post
	unset($_POST['submit']);//unsetting the submit 

	$deleAdm = $pdo->prepare('DELETE FROM image WHERE id=:id'); //delete from the image from database
		if(  $deleAdm->execute(['id'=>$dAdminImage])  ){ 
				header('location:image'); //redirect page
		}

}

?>

<main>

<u><a href="addImage">+ Add Images</a></u><!-- link to add image  -->

<br>

<?php
$images = $pdo->prepare('SELECT * FROM image'); //select from image 
$images->execute(); //executing 
$image=$images->fetchAll();//fetching all 

echo '<table>';
echo '<thead>';
echo '<tr>';
echo '<th>Image</th>';// image 
echo '<th>Action</th>'; //action for image 
echo '</tr>';

foreach($image as $i){ //for each is used 
    echo '<tr>';
    echo '<td>
    <a href="images/furniture/' .$i['image']  . '">
    <img style="width:100px;"   src="images/furniture/' . $i['image'] . '" /></a>	
    </td>';
    echo '<td>'; ?>
    	<form  method="POST"><!--form with post method  -->
						<input type="hidden" name="delImage" value="<?php echo $i['id']; ?>"><!--deleting the image  -->
						<input type="submit" name="submit" value="Delete"><!-- confirm delete -->
		</form>

<?php    echo '</td>';
    echo '</tr>';
}

echo '</thead>';
echo '</table>';
?>



</main>