<?php
require '../db/db.php';// connection is made 


if(  isset($_POST['delFurniture'])  ){  //if isset is used 
	$dFurnitureNo = $_POST['delFurniture']; //post for deleing the furniture
	unset($_POST['delFurniture']);//unset is used 
	unset($_POST['submit']); //unset post for submit 

	$deleAdm = $pdo->prepare('DELETE FROM furniture WHERE id=:id'); //pdo is used to delete the furniture  
		if(  $deleAdm->execute(['id'=>$dFurnitureNo])  ){ //executing the deleting furniture
				header('location:furniture'); // location is set to furniture page
		}

}


function Iscategory($id){ //function is made  
	require '../db/db.php'; //connection is made
	$Categoryname = $pdo->prepare('SELECT name FROM category WHERE id=:id'); //pdo prepare for select query 
	$Categoryname->execute(['id'=>$id]); //executing
	$name =$Categoryname->fetchColumn();// fetching clolumn
	return $name; //return
}

?>
<main >
<br>
<h2 style="text-align:center;"><u>Furniture</u></h2> <!-- link to furniture -->
<br>
<div style="padding:20px;"> <!-- style is added -->
<a href="add-editFurniture"><u>  +  Add Furniture  </u></a> <!-- link to add the furniture -->
<br>

<?php 
$adFurnitures = $pdo->prepare('SELECT * FROM furniture');//selet query
$adFurnitures->execute(); //execute
$afFurniture =$adFurnitures->fetchAll(); //fethcing all 
echo '<table>';
			echo '<thead>'; //print 
			echo '<tr>';//print 
			echo '<th>Name</th>';//print 
			echo '<th>Description</th>';//print 
			echo '<th>Category</th>';//print 
			echo '<th>Price</th>';//print 
			echo '<th>Display</th>';//print 
			echo '<th>Action</th>';//print 
			echo '</tr>';//print  


foreach($afFurniture as $furniture){ //for each is used 
	echo '<tr>';//print 
	echo '<td>' . $furniture['name'] . '</td>';//print  name of furniture
	echo '<td>' . $furniture['description'] . '</td>'; //print  description 
	echo '<td>'.Iscategory($furniture['categoryId']).'</td>';//print  category id
	echo '<td>' . $furniture['price'] . '</td>'; //print price 
	echo '<td>' . $furniture['display'] . '</td>';//print  display to shown and hidden 
	echo '<td style="display:flex;float:right;">   '?><!--styke is used -->
		<form  method="POST" action="add-editFurniture"> <!--form created wuith post method -->
			<input type="hidden" name="editFurniture" value="<?php echo $furniture['id']; ?>"> <!--input for editing the furniture id -->
			<input type="hidden" name="hiddenName"  value="<?php echo $furniture['name']; ?>"              ><!--input for editing the furniture  name-->
			<input type="hidden" name="hiddenDescription"  value="<?php echo $furniture['description']; ?>" ><!--input for editing the furniture desctiption-->
			<input type="hidden" name="hiddenPrice"   value="<?php echo $furniture['price']; ?>"             ><!--input for editing the furniture price  -->
			<input type="submit" name="submit" value="Edit"><!--submitting the form -->
		</form>
		<form  method="POST"> <!--post method for form -->
			<input type="hidden" name="delFurniture" value="<?php echo $furniture['id']; ?>"><!-- input for deleting furniture-->
			<input type="submit" name="submit" value="Delete"><!-- submit delete-->
		</form>
	<?php echo '</td></tr>';

}
echo '</thead>';
echo '</table>';

?>
</div>
</main>