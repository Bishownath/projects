<?php 
require '../db/db.php'; //connection is made

if(  isset($_POST['delCategory'])  ){ //if and isset is used
	$dCategoryNo = $_POST['delCategory']; //delete category unset 
	unset($_POST['delCategory']);//delete category unset
	unset($_POST['submit']); //submit unset

	$deleCategory = $pdo->prepare('DELETE FROM category WHERE id=:id'); //deleteing from the category 
		if( $deleCategory->execute(['id'=>$dCategoryNo ])  ){ //if condition for executing the id 
				header('location:category'); //location is category page
		}

}

function adminCategories(){ //function is created
	
require '../db/db.php';//connection is made 


echo '<h3><u><a href="add-editcategory"> + Add category  </a></u></h3>';

$presentCat = $pdo->prepare('SELECT * FROM category'); //selecting from category from database
$presentCat->execute();// executing 
$pcategory =$presentCat->fetchAll(); //fetching 


		echo '<table style="text-align:center;">';
			echo '<thead>';
			echo '<tr>';
			echo '<th>Category</th>';
			echo '<th>Action</th>';
			echo '</tr>';

foreach ($pcategory as $key ) { //for each is used
	echo '<tr>'; 
	echo'<td>'.$key['name'].'</td>'; 
	echo '<td>'; ?>
		<div style="display: flex;float:right;">
		<form action="add-editcategory" method="POST"> <!-- form is created-->
						<input type="hidden" name="editOldName"value="<?php echo $key['name'] ;?>"  > <!-- inpout for name-->
						<input type="hidden" name="editCategory" value="<?php echo $key['id']; ?>"><!-- input for id-->
						<input type="submit" name="submit" value="Edit"><!--submit -->
					</form>
					<form  method="POST"><!-- form created using post-->
						<input type="hidden" name="delCategory" value="<?php echo $key['id']; ?>"><!-- input for delete category-->
						<input type="submit" name="submit" value="Delete"><!-- input for submitting delete confirm-->

					</form>
		</div>			
	<?php				
	echo '</td>';

	echo '</tr>';
}

echo '</thead>';	
echo '</table>';




}









?>




<main class="admin">
<br>
<h2  style="text-align:center;"><u>Categories</u></h2>

<div style="padding:60px;">
	<?php adminCategories(); ?>
</div>


</main>