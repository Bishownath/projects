
<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="styles.css"/> <!-- connecting the css -->
		<title><?php echo $titleOf;?></title><!-- title from the page -->
	</head>
	<body>
	<header>
		<section>
			<aside>
				<h3>Opening Hours:</h3> 
				<p>Mon-Fri: 09:00-05:30</p>
				<p>Sat: 09:00-05:00</p>
				<p>Sun: 10:00-04:00</p>
			</aside>
			<h1>Fran's Furniture</h1>

		</section>
	</header>
	<nav>
		<ul>
			<li><a href="home">Home</a></li><!-- link to home-->
			<li><a href="furniture">Furnitures</a></li><!-- link to furniture-->
			<?php if(isset($_SESSION['sessType'])){ ?><!-- link to type-->
				<li><a href="category">Categories</a></li><!-- link to category-->
				<li><a href="image">Images</a></li><!-- link to images -->
					<?php  if( $_SESSION['sessType'] == 'Super-Admin'  ){ ?>

							<li><a href="adminuser">Admins</a></li> <!-- chooses admins -->

					<?php  } ?>
					
					<li><a href="enquiry">Enquiry</a></li> <!-- link to enquiry-->
					<li><a href="logout.php">Log out</a></li><!-- link to logout-->
			<?php } else {?>
				<li><a href="about">About Us</a></li> <!-- link to about us-->
				<li><a href="contact">Contact us</a></li><!-- link to contact us-->
				<li><a href="FAQ">FAQ</a></li><!-- link to faq-->
				<li><a href="loginProcess">Login</a></li><!-- link to login process-->
			<?php } ?>
		</ul>

	</nav>
<img src="images/randombanner.php"/>

		<?php echo $contentOf; ?> <!-- content of the layout-->


	<footer><!-- footer part--> 
		&copy; Fran's Furniture <?php  echo date('Y');  ?><!-- copyright section -->
	</footer> 
</body>
</html>



