<main class="home">

	<h1><u>Login</u></h1> <!-- link to login-->


<form  method="POST" style="text-align: center; display: inline-block; display: inline-grid;"><!--form created with post method -->

		<label>Username:</label> <!--label username -->
        <input type="text" name="username" style="text-align:center; width: 100%;" placeholder="Enter username" required /><!-- input type text for username with placeholder-->
        <br><br>

        <label>Password:</label> <!-- label password -->
        <input type="password" name="password" style="text-align:center; width: 100%;" placeholder="Enter password" required/><!--password input type with placeholder -->


        <input type="submit" name="sooLogin" value="Log In" style="width: 50%; text-align: center;"/><!-- submit to login-->



</form>
</main>

<?php

if(isset($_POST['sooLogin'])){//if condition
    require "../db/db.php";//connecting database
    $stmt= $pdo->prepare('SELECT * FROM tbl_admin WHERE username= :username and password= :password');//select from table user
    $criteria= [//criteria array
        'username'=> $_POST['username'],
        'password'=>$_POST['password']
    ];

    $stmt->execute($criteria);//execute criteria
    if($stmt-> rowCount() > 0){
        $row= $stmt->fetch();//fetch statement
        $_SESSION['sessUID']= $row['id']; //session  for id
        $_SESSION['sessUname']= $row['username'];//session for username
        $_SESSION['sessType'] = $row['type'];//session for type
        header('Location:../public/index.php');//location for index page

        ?>
            <?php
    }

    else{
        echo "<script type='text/javascript'>"; //for alert message on the screen
		echo "alert('Username or password incorrect.');"; //message
		echo "</script>";

    }
}

?>
