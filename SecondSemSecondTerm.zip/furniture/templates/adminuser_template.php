<?php 
require '../db/db.php';//connection is made

if(  isset($_POST['delValue'])  ){ //if isset is usded
	$dAdminNo = $_POST['delValue']; //delete value from post method
	unset($_POST['delValue']); //unseting the delete 
	unset($_POST['submit']);//unsetting the submit

	$deleAdm = $pdo->prepare('DELETE FROM tbl_admin WHERE id=:id');//deleting from the tableadmin 
		if(  $deleAdm->execute(['id'=>$dAdminNo])  ){ // if condition is used
				header('location:adminuser'); //location is admin user page
		}

}




?>


<main>
	
<div style="padding:20px;color:black;font-size:20px;"> <!--style is used insdie div -->
	<u><a href="add-editadmin"> + Add new administrator</a></u><!-- link to add new administrator-->
</div>
<br>

<div style="text-align:center;"> 
		<h2><u>Listed Administrators</u></h2> <!-- admin list on adding the new admin-->

		<br>

<?php 

$adminS  = $pdo->prepare('SELECT * FROM tbl_admin WHERE type=:type'); //selecting from the table admin
$adminS->execute(['type'=>'Admin']);//executing 
$onlyAdmin = $adminS->fetchAll(); //fetching 

if( $adminS->rowCount()>0 ){ //if condition

		echo '<table>'; 
			echo '<thead>';
			echo '<tr>';
			echo '<th>Id</th>';
			echo '<th>Name</th>';
			echo '<th>Email</th>';
			echo '<th>Username</th>';
			echo '<th>Action</th>';
			echo '</tr>';
	foreach ($onlyAdmin as $theseAdmins) { //for each is used
				echo '<tr>';
				echo '<td>' . $theseAdmins['id'] . '</td>'; //print id
				echo '<td>' . $theseAdmins['name'] . '</td>';//print name
				echo '<td>' . $theseAdmins['email'] . '</td>';//print email
				echo '<td>' . $theseAdmins['username'] . '</td>';//print username
				echo '<td style="display:flex;float:right;">   '?>
					<form action="add-editadmin" method="POST"> <!--form created using post method  -->
						<input type="hidden" name="editValue" value="<?php echo $theseAdmins['id']; ?>"><!-- input for id-->
						<input type="hidden" name="hiddenName"  value="<?php echo $theseAdmins['name']; ?>"   > <!-- input for name-->
						<input type="hidden" name="hiddenEmail"  value="<?php echo $theseAdmins['email']; ?>" ><!-- input for email-->
						<input type="hidden" name="hiddenUsername"  value="<?php echo $theseAdmins['username']; ?>" ><!-- input for username-->
						<input type="submit" name="submit" value="Edit"><!-- input for submit-->
					</form>
					<form  method="POST"><!-- form using  post -->
						<input type="hidden" name="delValue" value="<?php echo $theseAdmins['id']; ?>"><!-- input for deleting-->
						<input type="submit" name="submit" value="Delete"><!-- submitting  -->
					</form>
				<?php echo '</td></tr>';
}

echo '</thead>';	
echo '</table>';
}
else{
		echo 'No administrators found. Add new administrators.'; //else condition if the condition if is not satisfied
}

 ?>
</div>

	
</main>



