<?php 


if(  isset($_POST['fullname']) && isset($_POST['address']) 
 &&  isset($_POST['email'])		&&  isset($_POST['comment'])     ){ //if condition is used with isset and setting the fullname and address and email and comment 

 	require '../db/db.php'; //connection

 $insertCom = $pdo->prepare('INSERT INTO tbl_contact (fullname,address,email,comment) 
 								VALUES (:fullname,:address,:email,:comment)'); //inserting into table contact with values 

 if(  $insertCom->execute([ 'fullname'=>$_POST['fullname'] , 'address'=>$_POST['address'] , 
 							'email'=>$_POST['email'] ,'comment'=> $_POST['comment']  ]) ){

unset($_POST); //unsetting the post method 
header('location:contact');//location is contact page
 }

}

?>
<main class="home"> <!-- main class -->

		<p>Please call us on  01604 90345 or email <a href="mailto:enquiries@fransfurniture.co.uk">enquiries@fransfurniture.co.uk</a> <!-- paragraph -->
 
	<form method= "POST"><!-- Using post method-->

		<label>Full name:</label><!-- Full Name-->
 		<input type="text" name="fullname"   required /><br><!-- input need to be added and if not added then required make it mandatory-->

 		<label>Address: </label><!-- address-->
		<input type="text" name="address"   required />

		<label>Email: </label><!-- Email-->
		<input type="text" name="email"   required /><!-- input need to be added and if not added then required make it mandatory-->

		<label>Comment:</label><!-- comment-->
		<textarea  placeholder="This is the comment section......"  name="comment"  style="resize:none;width:100%;height:100px;" >
			
			
		</textarea><!-- text area for comment -->
		<input type="submit" name="submit"  value="submit" id="submit"/><!-- input for confirm -->
	</form>

</main>


