<?php //staring of php code
require '../db/db.php';//calling database connection

if( isset($_POST['name'])  &&  isset($_POST['description']) && isset($_POST['price'])  && isset($_POST['categoryId']) ){
//if method used
	if($_POST['foreditfurniture'] == ''){//If condition used in POST method
	$insertAdFurniture= $pdo->prepare("INSERT INTO furniture (name,description,price,categoryId,display) #inserting into furniture table
                                 VALUES (:name,:descris,:prices,:categorysId,:displays)");//  inserting the values to the database 
        if(  $insertAdFurniture->execute(['name'=>$_POST['name'],'descris'=>$_POST['description'],
                                            'prices'=>$_POST['price'],
                                            'categorysId'=>$_POST['categoryId'],
									'displays'=>$_POST['display']    ])    ){ //executing the inserted furnitures
			header('location:furniture');//header location set to furniture page
		}	
	}

	else{ //else condition 

$updateAdFurniture= $pdo->prepare('UPDATE furniture SET name=:name,description=:description,price=:price,categoryId=:categoryId,display=:display 
							 WHERE id=:id'); //udating the furniture database

	if(  $updateAdFurniture->execute([ 'id'=>$_POST['foreditfurniture'] ,'name'=>$_POST['name'],'description'=>$_POST['description'],
                                                'price'=>$_POST['price'],
                                                'categoryId'=>$_POST['categoryId'],
                                            'display'=>$_POST['display']
		                              ])   ){ //if condition for executing
         header('location:furniture'); //header location set to futniture page after execute
	}


	}


}



?>
<main> 

<form method="POST"> <!--creating the form -->
        <label >Name:</label> <!-- name label -->
        <input type="text" name="name" value="<?php if(isset($_POST['hiddenName'])){   echo $_POST['hiddenName']; } ?>" required> <!--input for the name -->
        <label >Description:</label> <!-- Description label-->
        <textarea name="description" required > 
<?php  if(isset($_POST['hiddenDescription'])){   echo $_POST['hiddenDescription']; } ?> 
        </textarea>
        <label >Price</label> <!--Label for price -->
        <input type="number"  min="1" name="price" value="<?php  if(isset($_POST['hiddenPrice'])){   echo $_POST['hiddenPrice']; } ?>" required> <!-- input for price in dropdown type-->
        <label>Category:</label><!-- label category-->
    <select name="categoryId" > <!-- selecting the category id -->
<?php 
    $lsitCateg = $pdo->prepare('SELECT * FROM category'); //selecting the cat id from the database
    $lsitCateg->execute();//executing 
    $list=$lsitCateg->fetchAll(); //fetching the list
    foreach ($list as $LLkey) {?> <!--using for each -->
        <option value="<?php echo $LLkey['id']?>"><?php echo $LLkey['name']?></option> <!-- option value -->
 <?php   }

?>
    </select>
        <label>Display:</label> <!--Label display -->
    <select name="display" > <!-- select the display -->
        <option value="Shown">Shown</option> <!--option for showing the itemes  -->
        <option value="Hidden">Hidden</option> <!--option for hiding the element  from the user-->
    </select>
        <input type="hidden" name="foreditfurniture" value="<?php    if(isset($_POST['editFurniture'])){   echo $_POST['editFurniture']; } ?>">
        <input type="submit" name="submit" value="Save Furniture"> <!--submitting the form  -->
</form>
</main>