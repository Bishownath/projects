<?php
require '../db/db.php'; //requiring the database 
if(isset($_POST['name'])){ //if condition for isset and post method
	if($_POST['toeditcategory']==''){ //if condition 
		$categoryInsert = $pdo->prepare('INSERT INTO category (name) VALUES (:namm) '); //inserting values into category 
		if($categoryInsert->execute(['namm'=>$_POST['name']])  ){ //executing
			header('location:category'); //location is set to category page 
		}
	}
	else{
		$categoryUpdate = $pdo->prepare('UPDATE category SET name=:nam WHERE id=:id'); //updating the category 
		if($categoryUpdate->execute(['id'=> $_POST['toeditcategory'] ,'nam'=>$_POST['name']   ])){// executing 
				header('location:category');//location to category page
		}
	}
}



?>
<main class="home"> <!--main class named home -->
<h2><u>Add new category</u></h2> <!--  link for adding the category-->

<form method="POST"> <!-- form is created with POST method-->
	<label>Category name:</label><!--label as category name -->
	<input type="text" name="name"   value="<?php  if( isset($_POST['editOldName'])){ echo $_POST['editOldName']; }  ?>"  required> <!-- input for the name-->
	<input type="hidden" name="toeditcategory"  value="<?php  if( isset($_POST['editCategory'])){ echo $_POST['editCategory']; }  ?>"><!-- input is hidden-->
	<input type="submit" name="submit" value="Save Category"><!-- submitting the form-->

</form>

</main>