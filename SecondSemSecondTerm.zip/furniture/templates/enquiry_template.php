<?php

require "../db/db.php"; //connectoon 
 
if(isset($_POST['reviewThis'])){//if condition for post method for reviewing 
 
require "../db/db.php";//connection

	$revNo = $_POST['reviewThis']; //post method for reviewing 
	unset($_POST['reviewThis']);//unsetting the post method

	$updateRev = $pdo->prepare("UPDATE tbl_contact SET reviewed_by=:reviewed_by WHERE id=:id");//updating the table contact 

	if(  $updateRev->execute(['id'=>$revNo , 'reviewed_by'=> $_SESSION['sessUID']    ])  ){

			header('Location:enquiry');//location is set to enquiry page

	}
}

 ?>
<main class="home">
	
	<h2><u>Enquiries</u></h2> <!--link to enquiry -->
	<br>
	<br>
<?php 
require "../db/db.php"; //connection

function nameOf($id){//function is made
	require "../db/db.php";//connection

	$name = $pdo->prepare('SELECT username FROM tbl_admin WHERE id=:id'); //selecting username from the table admin
	$name->execute(['id'=> $id]); //executing 

	$un = $name->fetchColumn(); //fetching
	return $un;

}
function revBy($rid,$uid){ //function is created

	if( $uid==''  ){ //if condition
			return '
				<form method="POST">
					<input type="hidden" name="reviewThis" value =" '.$rid.'">
					<input type="submit" name="Submit" value="Review">
				</form>
			';
	}

	else{ 
			return 'Reviewed by ' . nameOf($uid);
	}
}

$bishENQ = $pdo->prepare('SELECT * FROM  tbl_contact ORDER BY id DESC'); //selecting from table contact 
$bishENQ->execute();

if($bishENQ->rowCount()>0){
	$ENQ = $bishENQ->fetchAll(); //fetching

	echo '<table>';
			echo '<thead>';
			echo '<tr>';
			echo '<th>Name</th>';
			echo '<th>Address</th>';
			echo '<th>Email</th>';
			echo '<th>Comment</th>';
			echo '<th>Admin reviewed</th>';
			echo '</tr>';

	foreach ($ENQ as $enq) {
		echo '<tr>';

		echo '<td>'.$enq['fullname'].'</td>'; //printing the fullname
		echo '<td>'.$enq['address'].'</td>';// print address
		echo '<td>'.$enq['email'].'</td>';//prints email
		echo '<td>'.$enq['comment'].'</td>';// prints comment 
		echo '<td>'.revBy($enq['id'],$enq['reviewed_by']).'</td>'; //print the reviewed by 	

		echo '</tr>';	
	}


echo '</thead>';	
echo '</table>';

}

else{
	echo "No enquiries found!!!";   //printing message
}















?>	
</main>