<main class="home">
	
<h1 style="padding:250px; text-align: center">FAQ coming soon !!!</h1> <!-- setting heading -->


</main>