<?php
function loadTemplateof($filename, $tempVars){ //funtion load template of is created 
	extract($tempVars);//extracting the parameter of the function
	ob_start(); //ob start
	require $filename; //requiring the filename
	$content = ob_get_clean(); //content to ob get clean 
	return $content; //content return
}