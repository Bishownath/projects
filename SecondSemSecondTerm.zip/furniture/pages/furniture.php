<?php

$titleOf = 'Furniture';//title of the page

if(isset($_SESSION['sessType'])){ 
	$contentOf = loadTemplateof('../templates/adminFurniture_template.php', []);//content of the page
}
else{
	$contentOf = loadTemplateof('../templates/notFurniture_template.php', []);//content of the page
}


?>