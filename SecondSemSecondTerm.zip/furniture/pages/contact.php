<?php
$titleOf = 'Contact Page';//title of the page
$contentOf = loadTemplateof('../templates/contact_template.php', []);//content of the page