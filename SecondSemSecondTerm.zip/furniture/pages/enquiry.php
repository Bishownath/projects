<?php
$titleOf = 'Enquiries';//title of the page
$contentOf = loadTemplateof('../templates/enquiry_template.php', []);//content of the page


?>