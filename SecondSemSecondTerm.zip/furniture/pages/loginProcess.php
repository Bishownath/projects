

<?php
$titleOf = 'Login';//title of the page
$contentOf = loadTemplateof('../templates/login_template.php', []);//content of the page

?>