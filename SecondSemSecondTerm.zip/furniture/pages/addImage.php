<?php
$titleOf = 'Add Images';//title of the page
$contentOf = loadTemplateof('../templates/addImage_template.php', []);//content of the page
?>