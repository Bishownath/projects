<?php
$titleOf = 'Add/Edit Furniture';//title of the page
$contentOf = loadTemplateof('../templates/addeditFurniture_template.php', []);//content of the page


?>