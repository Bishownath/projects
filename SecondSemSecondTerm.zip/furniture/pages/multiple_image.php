<?php
$titleOf = 'Image'; //title of the page
$contentOf = loadTemplateof('../templates/multiple_image_template.php', []);//content of the page 