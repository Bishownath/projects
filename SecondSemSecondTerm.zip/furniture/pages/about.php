<?php
$titleOf = 'About Page'; //title of the page
$contentOf = loadTemplateof('../templates/about_template.php', []);//content of the page 