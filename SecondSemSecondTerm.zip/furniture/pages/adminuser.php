<?php
$titleOf = 'Administrators';//title of the page
$contentOf = loadTemplateof('../templates/adminuser_template.php', []);//content of the page


?>