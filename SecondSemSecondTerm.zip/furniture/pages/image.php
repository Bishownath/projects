<?php
$titleOf = 'Images';//title of the page
$contentOf = loadTemplateof('../templates/images_template.php', []);//content of the page
?>