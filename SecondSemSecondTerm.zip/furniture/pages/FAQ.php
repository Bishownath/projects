
<?php
$titleOf = 'FAQ';//title of the page
$contentOf = loadTemplateof('../templates/faq_template.php', []);//content of the page