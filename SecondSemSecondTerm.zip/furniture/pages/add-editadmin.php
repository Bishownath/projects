<?php
$titleOf = 'Add/Edit Administrators';//title of the page
$contentOf = loadTemplateof('../templates/addoreditadmin_template.php', []);//content of the page


?>