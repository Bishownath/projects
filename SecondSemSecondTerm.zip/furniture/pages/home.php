<?php
$titleOf = 'Home Page';//title of the page
$contentOf = loadTemplateof('../templates/home_template.php', []);//content of the page