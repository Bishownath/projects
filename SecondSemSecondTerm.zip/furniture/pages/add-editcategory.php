

<?php
$titleOf = 'Add/Edit Category';//title of the page
$contentOf = loadTemplateof('../templates/addoreditcategory_template.php', []);//content of the page


?>