<?php
$titleOf = 'Contact Page';//title of the page
$contentOf = loadTemplateof('../templates/category_template.php', []);//contentof the page

?>