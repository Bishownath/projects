<?php

session_start(); //session has been started 

	require '../function/templateLoad.php'; //requiring the fuction template load 

	if(isset($_GET['page'])){ //if condition fo the getting page
		require '../pages/' . $_GET['page'] . '.php'; //requiring the pages using GET method
	}
	else{ //else condition  
		require '../pages/home.php';  //requiring the pages home 
	}
 
	$tempVars = [ //array for temp vars
		'titleOf' => $titleOf, //title of page for temporary variable
		'contentOf' => $contentOf //content of page for temporary variable
	];
	$html = loadTemplateof('../templates/layout.php', $tempVars); //using html load template 
	echo $html;  //printing the html content
?>	

