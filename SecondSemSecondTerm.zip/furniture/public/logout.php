<?php

session_start(); //session start
session_unset(); //session unset
session_destroy(); //session destroy

header("Location:./index.php"); //header location set to index page i.e. home page
ob_end_flush();  //flush is used 
require 'index.php'; //including the index page
require "../templates/footer.php";// requiring the footer page


?>

